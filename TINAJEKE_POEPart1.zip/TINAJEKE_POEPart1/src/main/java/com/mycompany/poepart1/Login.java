/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.poepart1;

/**
 *
 * @author RC_Student_lab
 */
class Login {
 
    public boolean checkPasswordComplexity (String password){
    //check if the password is at least 9 letters long and contains
    //at least one uppercase letter, one digit, and one special letter
      if (password.length() >= 8 ||
              
        password.matches(". [A-Z].*")|| //contains at least one uppercase letter
              
        password.matches(".*[a-z].*")||
              
        password.matches(".*[0-9].*")||
              
        password.matches(".*[!@#$%67*()].*"))
        
            return true;
            
            else{ 
                    return false;
      }         
       }
      public boolean verifyPassword(String verifyPassword,String password){
       if (verifyPassword.equals(password)) {
           return true;
       }else{
           return false;
       }
       }  
      
      
    
    public boolean checkUsername (String Username){
        if (Username.contains("_") && Username.length()<=5){
            return true;
        }else{
            return false;
        }
    }
            public boolean verifyUsername (String verifyUsername,String username){
                if(verifyUsername.matches(username)){
        return true;
        
            }else{
    return false;
}
            }
    public boolean checkCellphoneNumber (String CellPhone){
       if(CellPhone.startsWith("+27")&& CellPhone.length()== 12 && CellPhone.matches(".*[0-9].*")){
           return true;
       }else{
           return false;
       }
        
    }

    public boolean login(String username, String password, String verifyUsername, String verifyPassword) {
        if (verifyUsername.equals(username)&& verifyPassword.matches(password)){
            System.out.println("Login successful, Welcome "+username+"!");
            return true;
                    }else{
            System.out.println("Login unsuccessful, Please try again");
            return false;
        }
    }
}
    






