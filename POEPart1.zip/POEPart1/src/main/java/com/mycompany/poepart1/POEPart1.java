/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.poepart1;

/**
 *
 * @author RC_Student_lab
 */
import java.util.Scanner;
public class POEPart1 {

    public static void main(String[] args) {
       
        
        //Creating an instance to create a class
        Login objLogin = new Login ();
        
        //Creating a scanner class
        Scanner input = new Scanner (System.in);
        
        //Prompting the username 
        
        System.out.println("Please enter your username");
        //User enters the username
        String username = input.nextLine();
        
        //Using if statements to check the username
        if(objLogin.checkUsername (username)==true){
            //Displaying the results
            System.out.println("Thank you for the username");
        }else{
            System.out.println("The username is incorrectly formatted");
         
        }
        
        
           
        //prompt user to enter password
        System.out.println("Please enter enter password");
        //enters password
        String password = input.nextLine();
        //using if statement to check password
        if (objLogin.checkPasswordComplexity(password)== true) {
            //display results
            System.out.println("Password successfully captured");
        }else{
            //display results
            System.out.println("Password unsuccesfully captured");
        }  
            //prompt the user to enter a cellphone number
            System.out.println("enter your cellphone number and include the SA format");
            
            String CellphoneNumber = input.nextLine();
            
            //using if statement to check cellphone number
            if (objLogin.checkCellphoneNumber(CellphoneNumber)){
                //display results
                System.out.println("Cellphone Number succesfully captured");
            
                } else {
                //display results
               System.out.println("Cellphone Number unsuccessfully captured");
                
        }
    
}
}