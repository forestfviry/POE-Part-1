/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.poepart1;

/**
 *
 * @author RC_Student_lab
 */
class Login {
 
    public boolean checkPasswordComplexity (String password){
    //check if the password is at least 9 letters long and contains
    //at least one uppercase letter, one digit, and one special letter
      if (password.length() >= 8 &&
              
        password.matches(". [A-Z].*")&& //contains at least one uppercase letter
              
        password.matches(".*[a-z].*")&&
              
        password.matches(".*[0-9].*")&&
              
        password.matches(".*[!@#$%67*()].*"))
        
            return true;
            
            else{ 
                    return false;
                    
       }
}
    
    public boolean checkUsername (String Username){
        if (Username.contains("__") && Username.length()==5){
            return true;
        }else{
            return false;
            
        }
    }
    
    public boolean checkCellphoneNumber (String CellphoneNumber){
        boolean check = false;
        if (CellphoneNumber.matches(".*[0-9].*")&&
                CellphoneNumber.startsWith(".*[+27].*")&&
                CellphoneNumber.length()==9)
            check= true;
        else{
            check= false;
            
        }
        
       return  check;
    }
}
